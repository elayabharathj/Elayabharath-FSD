package com.fsd.taskmanagement;

import com.fsd.taskmanagement.app.TaskManagementApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TaskManagementApplication.class)
public class TaskManagementApplicationTests {

	@Test
	public void contextLoads() {
	}

}
