package com.fsd.taskmanagement.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(com.fsd.taskmanagement.app.TaskManagementApplication.class, args);
	}
}
